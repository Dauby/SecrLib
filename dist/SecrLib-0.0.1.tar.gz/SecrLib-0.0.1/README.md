# SecrLib

SecrLib is a python library.

Logging :
\log(fname, content)\
.Logs something to a file.

