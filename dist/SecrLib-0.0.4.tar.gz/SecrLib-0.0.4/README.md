# SecrLib

SecrLib is a python library.

To install :

pip install SecrLib

To import :

example (
    from Secr import logs
)

## Logging :

log(fname, content)

// Logs something to a file

logcopy(fname, ffname)

// copys a file to another file

logcopyremove(fname, ffname)

// Copys a log to a file, then deletes the first file

logmake(fname)

// makes a file

logdelete(fname)

// deletes a file

## Math :


// returns the calculation of the slope of a set of coordinates

math.addone(num1)

// returns the number plus 1

math.subone(num1)

// returns the number minus 1

math.midpointxcoord(x1, x2)

// returns the midpoint of the x coordinate

math.midpointycoord(y1, y2)

// returns the midpoint of the y coordinate
