def slope(x1, y1, x2, y2):
    mksure = int(x1)
    mksure1 = int(x2)
    x3 = mksure1 - mksure
    mksure2 = int(y1)
    mksure3 = int(y2)
    y3 = mksure3 - mksure2
    xy1 = y3 / x3
    print(xy1)
