# SecrLib

SecrLib is a python library.

To install :
pip install SecrLib

To import :
example (
    from Secr import logs
)

Logging :

log(fname, content)
// Logs something to a file

